package com.example.computer.yogaapp;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class AddNewPose extends AppCompatActivity {
    MyDBHelper dbHelper;
    private EditText etID;
    private EditText etEnglishName;
    private EditText etSanskritName;
    private EditText etDescription;
    private ImageView ivPicture;
    private Button btnInsert;
    private Button btnUpdate;
    private Button btnDelete;
    private Button btnLoadAll;
    private TextView tvFinalData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_pose);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        dbHelper = new MyDBHelper(AddNewPose.this);
        init();


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    private void init() {
        etEnglishName = (EditText) findViewById(R.id.etEnglishName);
        etSanskritName = (EditText) findViewById(R.id.etSanskritName);
        etDescription = (EditText) findViewById(R.id.etDescription);
        ivPicture = (ImageView) findViewById(R.id.ivPicture);
        //picture needs to be converted to a byte array

        btnInsert = (Button) findViewById(R.id.btnInsert);
        btnUpdate = (Button) findViewById(R.id.btnUpdate);
        btnDelete = (Button) findViewById(R.id.btnDelete);
        btnLoadAll = (Button) findViewById(R.id.btnLoadAll);

        btnInsert.setOnClickListener(dbButtonsListener);
        btnUpdate.setOnClickListener(dbButtonsListener);
        btnDelete.setOnClickListener(dbButtonsListener);
        btnLoadAll.setOnClickListener(dbButtonsListener);

        tvFinalData = (TextView) findViewById(R.id.tvData);
    }

    private View.OnClickListener dbButtonsListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btnInsert:
                    long resultInsert = dbHelper.insert(getValue(etEnglishName), getValue(etSanskritName), getValue(etDescription),
                            getBytes(convertImageView(ivPicture))); //last field takes a byte array
                    //UI takes in type ImageView ivPicture
                    //ImageView is converted to a bit map convertImageView()
                    //BitMap is converted to byte array getBytes()
                    if (resultInsert == -1) {
                        Toast.makeText(AddNewPose.this, "Some error occurred while inserting", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(AddNewPose.this, "Data inserted successfully, ID: " + resultInsert, Toast.LENGTH_SHORT).show();
                    }
                    break;

                case R.id.btnUpdate:
                    long resultUpdate = dbHelper.update(Integer.parseInt(getValue(etID)), getValue(etEnglishName), getValue(etSanskritName), getValue(etDescription),
                            getBytes(convertImageView(ivPicture)));
                    if (resultUpdate == 0) {
                        Toast.makeText(AddNewPose.this, "Some error occurred while updating", Toast.LENGTH_SHORT).show();
                    } else if (resultUpdate == 1) {
                        Toast.makeText(AddNewPose.this, "Data updated successfully, ID: " + resultUpdate, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(AddNewPose.this, "Error, multiple records updated ", Toast.LENGTH_SHORT).show();
                    }

                    break;

                case R.id.btnDelete:
                    long resultDelete = dbHelper.delete(Integer.parseInt(getValue(etID)));
                    if (resultDelete == 0) {
                        Toast.makeText(AddNewPose.this, "Some error occurred while deleting", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(AddNewPose.this, "Data deleted successfully ", Toast.LENGTH_SHORT).show();
                    }
                    break;

                case R.id.btnLoadAll:
                    StringBuffer finalData = new StringBuffer();
                    Cursor cursor = dbHelper.getAllRecords();

                    for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                        finalData.append(cursor.getInt(cursor.getColumnIndex(MyDBHelper.ID)));
                        finalData.append(" - ");
                        finalData.append(cursor.getString(cursor.getColumnIndex(MyDBHelper.ENGLISH_NAME)));
                        finalData.append(" - ");
                        finalData.append(cursor.getString(cursor.getColumnIndex(MyDBHelper.SANSKRIT_NAME)));
                        finalData.append(" - ");
                        finalData.append(cursor.getString(cursor.getColumnIndex(MyDBHelper.DESCRIPTION)));
                        finalData.append(" - ");
                        finalData.append(cursor.getInt(cursor.getColumnIndex(MyDBHelper.PICTURE)));
                        finalData.append("\n");

                    }
                    tvFinalData.setText(finalData);
                    break;
            }
        }
    };

    private String getValue(EditText editText) {
        return editText.getText().toString().trim();
    }


    @Override
    public void onStateNotSaved() {
        super.onStart();
        dbHelper.openDB();
    }

    @Override
    protected void onStop() {
        super.onStop();
        dbHelper.closeDB();
    }

    // convert from bitmap to byte array
    public static byte[] getBytes(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
        return stream.toByteArray();
    }

    // convert from byte array to bitmap
    public static Bitmap getImage(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }

    //converts from imageView to BitMap
    public Bitmap convertImageView(ImageView image) {
        ImageView view = (ImageView) findViewById(R.id.ivPicture);
        view.setDrawingCacheEnabled(true);
        view.buildDrawingCache();
        Bitmap bm = view.getDrawingCache();
        return bm;
    }

    public static Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }

        final int width = !drawable.getBounds().isEmpty() ? drawable
                .getBounds().width() : drawable.getIntrinsicWidth();

        final int height = !drawable.getBounds().isEmpty() ? drawable
                .getBounds().height() : drawable.getIntrinsicHeight();

        final Bitmap bitmap = Bitmap.createBitmap(width <= 0 ? 1 : width,
                height <= 0 ? 1 : height, Bitmap.Config.ARGB_8888);

        Log.v("Bitmap width - Height :", width + " : " + height);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }


}


