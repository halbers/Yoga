package com.example.computer.yogaapp;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyPoses extends AppCompatActivity implements View.OnClickListener {
    private Button AddNewPoseButton;
    private Button SearchAllPoses;
    private MyDBHelper dbHelper;
    private ListView lvPosesItemLists;
    private ArrayList<MenuItem> menuItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_poses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        dbHelper = new MyDBHelper(this);
        init();

        AddNewPoseButton = (Button) findViewById(R.id.btnAddNewPose);
        AddNewPoseButton.setOnClickListener(this);

        SearchAllPoses = (Button) findViewById(R.id.btnSearchAllPoses);
        SearchAllPoses.setOnClickListener(this);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
    private void init() {
        lvPosesItemLists = (ListView) findViewById(R.id.list_poses_layout);

        lvPosesItemLists = (ListView) findViewById(R.id.list_poses_layout);
        lvPosesItemLists.setAdapter(new MainMenuViewAdapter(menuItems));
//TODO        lvPosesItemLists.setOnItemClickListener(new MenuItemClickListener(mainMenuItems));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnAddNewPose:
                startActivity(new Intent(this, AddNewPose.class));
                break;
            case R.id.btnSearchAllPoses:
                Cursor cursor = dbHelper.getAllRecords();

                menuItems.clear();
                for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                    String poseNameEnglish = cursor.getString(cursor.getColumnIndex(MyDBHelper.ENGLISH_NAME));
                    String poseNameSanskrit = cursor.getString(cursor.getColumnIndex(MyDBHelper.SANSKRIT_NAME));
                    String poseDescription = cursor.getString(cursor.getColumnIndex(MyDBHelper.DESCRIPTION));
                    String poseImagePath = cursor.getString(cursor.getColumnIndex(MyDBHelper.PICTURE));
                    Bitmap poseImage = ImageHelper.getBitmapFromAsset(this, poseImagePath);

                    MenuItem menuItem = new MenuItem(this, poseNameEnglish, poseNameSanskrit, poseDescription, poseImage);
                    menuItems.add(menuItem);
                }
                init();
                break;
        }
    }

    private class MainMenuViewAdapter extends BaseAdapter {
        private ArrayList<MenuItem> menuItems;

        public MainMenuViewAdapter(ArrayList<MenuItem> items) {
            this.menuItems = items;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the view for the menu item from the XML.
            View item = getLayoutInflater().inflate(R.layout.list_poses_layout, parent, false);

            // Get the image from the resources.
            ImageView imageView = (ImageView) item.findViewById(R.id.pose_image);
            imageView.setImageBitmap(menuItems.get(position).getImage());

            TextView poseNameEnglish = (TextView) item.findViewById(R.id.pose_name_english);
            poseNameEnglish.setText(menuItems.get(position).getPoseNameEnglish());
            TextView poseNameSanskrit = (TextView) item.findViewById(R.id.pose_name_sanskrit);
            poseNameSanskrit.setText(menuItems.get(position).getPoseNameSanskrit());
            TextView poseDescription = (TextView) item.findViewById(R.id.pose_description);
            poseDescription.setText(menuItems.get(position).getPoseDescription());

            // Return the view.
            return item;
        }

        @Override
        public int getCount() {
            return menuItems.size();
        }

        @Override
        public MenuItem getItem(int position) {
            return menuItems.get(position);
        }

        public int getIndexOf(MenuItem item) {
            return menuItems.indexOf(item);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
    }
}
