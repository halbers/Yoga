package com.example.computer.yogaapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends AppCompatActivity implements View.OnClickListener {
    //assign views that the login will contain
    Button loginButton;
    EditText editTextUN, editTextPass;
    TextView registerLink;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextUN = (EditText)findViewById(R.id.editTextUN);
        editTextPass = (EditText)findViewById(R.id.editTextPass);
        loginButton = (Button)findViewById(R.id.loginButton);
        registerLink = (TextView) findViewById(R.id.registerLink);

        loginButton.setOnClickListener(this);
        registerLink.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        switch(v.getId()) //gets the id of the view which notifies the onclick method, if the login method was the one who notified the method it
        {
            case R.id.loginButton:
                break;

            case R.id.registerLink:
                startActivity(new Intent(this, register.class));

                break;
        }
    }

    }

