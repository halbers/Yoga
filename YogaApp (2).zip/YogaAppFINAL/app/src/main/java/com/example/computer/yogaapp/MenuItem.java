package com.example.computer.yogaapp;

/**
 * Created by Stefan on 21/04/16.
 */


import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;

public class MenuItem extends View {
    private Bitmap image;
    private String poseNameEnglish;
    private String poseNameSanskrit;
    private String poseDescription;

    public MenuItem(Context context, String poseNameEnglish, String poseNameSanskrit, String poseDescription, Bitmap image) {
        super(context);
        this.poseNameEnglish = poseNameEnglish;
        this.poseNameSanskrit = poseNameSanskrit;
        this.poseDescription = poseDescription;
        this.image = image;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public String getPoseNameEnglish() {
        return poseNameEnglish;
    }

    public void setPoseNameEnglish(String poseNameEnglish) {
        this.poseNameEnglish = poseNameEnglish;
    }

    public String getPoseNameSanskrit() {
        return poseNameSanskrit;
    }

    public void setPoseNameSanskrit(String poseNameSanskrit) {
        this.poseNameSanskrit = poseNameSanskrit;
    }

    public String getPoseDescription() {
        return poseDescription;
    }

    public void setPoseDescription(String poseDescription) {
        this.poseDescription = poseDescription;
    }
}
