package com.example.computer.yogaapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MyDBHelper extends SQLiteOpenHelper{
    private static final String DB_NAME = "poses.db";
    private static final int VERSION = 3;

    private static final String TABLE_NAME = "myPoses";
    public static final String ID = "id";
    public static final String ENGLISH_NAME = "englishName";
    public static final String SANSKRIT_NAME = "sanskritName";
    public static final String DESCRIPTION = "description";
    public static final String PICTURE = "pictureId";

    private Context context;

    private SQLiteDatabase myDB;

    public MyDBHelper(Context context) {
        super(context, DB_NAME, null, VERSION);
        this.context = context;
        myDB = openDatabase();
    }

    public SQLiteDatabase openDatabase() {
        boolean isNewDb = false;
        // Open database.
        File dbFile = context.getDatabasePath(DB_NAME);
        // If database doesn't exist in the path.
        if (!dbFile.exists()) {
            // Create directory in parent file.
            dbFile.getParentFile().mkdirs();
            // create new database in /data/data/<package>/databases
            context.openOrCreateDatabase(DB_NAME,
                    SQLiteDatabase.CREATE_IF_NECESSARY, null);
            isNewDb = true;
        }

        myDB = SQLiteDatabase.openDatabase(dbFile.getPath(), null,
                SQLiteDatabase.OPEN_READWRITE);

        if (isNewDb) {
            onCreate(myDB);
            onUpgrade(myDB, 0, VERSION);
        }

        return myDB;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//create table
        String queryTable = "CREATE TABLE " + TABLE_NAME + " (" +
                ID + " INTEGER PRIMARY KEY, " +
                ENGLISH_NAME + " TEXT NOT NULL, " +
                SANSKRIT_NAME + " TEXT NOT NULL, " +
                DESCRIPTION + " TEXT NOT NULL, " +
                PICTURE + " TEXT NOT NULL " +
                ")";
        db.execSQL(queryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //TODO Add rest here.
        insertPreload( "Camel", "Ustrasana", "Lower back stretch", "poses/camel.jpg");
        insertPreload( "Cobra", "Bhujangasana", "Back strengthening", "poses/cobra.jpg");
        insertPreload( "Downward Dog", "adho mukha shvanasana", "This pose is called downward facing dog", "poses/downward_dog.jpg");
        insertPreload( "Forward Fold", "Uttanasana", "Hamstring stretch", "poses/forward_fold.jpg");
        insertPreload( "Rabbit", "Sasangasana ", "This pose is called downward facing dog", "poses/downward_dog.jpg");
        insertPreload( "Tortoise", "Kurmasana", "This pose is called downward facing dog", "poses/downward_dog.jpg");
        insertPreload( "Triangle", "Trikonasana", "This pose is called downward facing dog", "poses/downward_dog.jpg");
        insertPreload( "Upward Dog", "adho mukha shvanasana", "This pose is called downward facing dog", "poses/downward_dog.jpg");
        insertPreload( "Warrior 2", "adho mukha shvanasana", "This pose is called downward facing dog", "poses/downward_dog.jpg");
    }

    public void openDB(){
        myDB = getWritableDatabase();
    }
    public void closeDB(){
        if(myDB != null && myDB.isOpen()){
            myDB.close();
        }
    }
    public long insert(String englishName, String sanskritName, String description, byte[] picture ){
        ContentValues values = new ContentValues();
        if(picture != null) {
            values.put(ENGLISH_NAME, englishName);
            values.put(SANSKRIT_NAME, sanskritName);
            values.put(DESCRIPTION, description);
            values.put(PICTURE, picture);

            return myDB.insert(TABLE_NAME, null, values);
        }else{
            return myDB.insert(TABLE_NAME, null, values);
        }

    }
    public long insertPreload(String englishName, String sanskritName, String description, String pictureId){
        ContentValues values = new ContentValues();
        values.put(ENGLISH_NAME, englishName);
        values.put(SANSKRIT_NAME, sanskritName);
        values.put(DESCRIPTION, description);
        values.put(PICTURE, pictureId);

        return myDB.insert(TABLE_NAME, null, values);
    }

    public long update(int id, String englishName, String sanskritName, String description, byte[] picture ){
      ContentValues values = new ContentValues();
        values.put(ENGLISH_NAME, englishName);
        values.put(SANSKRIT_NAME, sanskritName);
        values.put(DESCRIPTION, description);
        values.put(PICTURE, picture);

        String where = ID + " = " + id;
        return myDB.update(TABLE_NAME, values, where, null);

    }
    public long delete(int id){
        String where = ID + " = " + id;
        return myDB.delete(TABLE_NAME, where, null);
    }

    //retrieving the data
    public Cursor getAllRecords(){
        String query = "SELECT * FROM " + TABLE_NAME;
        return myDB.rawQuery(query, new String[]{});
    }
}
