package com.example.computer.yogaapp;

import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class Upload extends AppCompatActivity {

    DBAdapter myDb;
    Calendar today = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    //just an edit text to test the database
    EditText etTasks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        etTasks = (EditText) findViewById(R.id.etTasks);
        openDB();
        populateListView();

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    //opens database
    private void openDB(){
        myDb = new DBAdapter(this);
        myDb.open();
    }

    public void onClick_AddTask(View v){
        today.getTime();
        String timeStamp = today.toString();
        //if statement to see if the box is not empty
        if(!TextUtils.isEmpty(etTasks.getText().toString())){
            //whatever is in the edit text will be added to the database
            myDb.insertRow(etTasks.getText().toString(), timeStamp);
        }
        populateListView();
    }

    private void populateListView(){
        Cursor cursor = myDb.getAllRows();
        //data from cursor put in list view
        String[] fromFieldNames = new String[]{DBAdapter.KEY_ROWID,DBAdapter.KEY_TASK};
        int[] toViewIDs = new int[]{R.id.textViewItemNumber,R.id.textViewItemTask};
        SimpleCursorAdapter myCursorAdapter;
        myCursorAdapter = new SimpleCursorAdapter(getBaseContext(),R.layout.content_upload,cursor,fromFieldNames,toViewIDs,0);
        ListView myList = (ListView) findViewById(R.id.listViewTasks);
        myList.setAdapter(myCursorAdapter);
    }

}
