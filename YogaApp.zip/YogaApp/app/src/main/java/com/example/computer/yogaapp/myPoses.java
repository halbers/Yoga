package com.example.computer.yogaapp;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;

public class myPoses extends AppCompatActivity implements View.OnClickListener {
    Button AddNewPoseButton;
    Button SearchAllPoses;
    MyDBHelper dbHelper;
    private TextView tvFinalData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_poses);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        dbHelper = new MyDBHelper(myPoses.this);
        init();

        AddNewPoseButton = (Button) findViewById(R.id.btnAddNewPose);
        AddNewPoseButton.setOnClickListener(this);

        SearchAllPoses = (Button) findViewById(R.id.btnSearchAllPoses);
        SearchAllPoses.setOnClickListener(this);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
    private void init() {
        //initialize images from drawable
        //Drawable downdog = ResourcesCompat.getDrawable(getResources(), R.drawable.downward_dog, null);
        Drawable downdog= ResourcesCompat.getDrawable(getResources(), R.drawable.downward_dog, null);;

        tvFinalData = (TextView) findViewById(R.id.tvData);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnAddNewPose:
                startActivity(new Intent(this, AddNewPose.class));
                
            case R.id.btnSearchAllPoses:
                Drawable downdog= ResourcesCompat.getDrawable(getResources(), R.drawable.downward_dog, null);;

                long insertPreloaded = dbHelper.insertPreload("Downward Dog", "adho mukha shvanasana", "This pose is called downward facing dog", getBytes(drawableToBitmap(downdog)));

                StringBuffer finalData = new StringBuffer();
                Cursor cursor = dbHelper.getAllRecords();

                for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                    finalData.append(cursor.getInt(cursor.getColumnIndex(MyDBHelper.ID)));
                    finalData.append(" - ");
                    finalData.append(cursor.getString(cursor.getColumnIndex(MyDBHelper.ENGLISH_NAME)));
                    finalData.append(" - ");
                    finalData.append(cursor.getString(cursor.getColumnIndex(MyDBHelper.SANSKRIT_NAME)));
                    finalData.append(" - ");
                    finalData.append(cursor.getString(cursor.getColumnIndex(MyDBHelper.DESCRIPTION)));
                    finalData.append(" - ");
                    finalData.append(cursor.getInt(cursor.getColumnIndex(MyDBHelper.PICTURE)));
                    finalData.append("\n");

                }
                tvFinalData.setText(finalData);
                break;
        }
    }
    // convert from bitmap to byte array
    public static byte[] getBytes(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
        return stream.toByteArray();
    }

    // convert from byte array to bitmap
    public static Bitmap getImage(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }

    //converts from imageView to BitMap
    public Bitmap convertImageView(ImageView image) {
        ImageView view = (ImageView) findViewById(R.id.ivPicture);
        view.setDrawingCacheEnabled(true);
        view.buildDrawingCache();
        Bitmap bm = view.getDrawingCache();
        return bm;
    }
    public static Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }

        final int width = !drawable.getBounds().isEmpty() ? drawable
                .getBounds().width() : drawable.getIntrinsicWidth();

        final int height = !drawable.getBounds().isEmpty() ? drawable
                .getBounds().height() : drawable.getIntrinsicHeight();

        final Bitmap bitmap = Bitmap.createBitmap(width <= 0 ? 1 : width,
                height <= 0 ? 1 : height, Bitmap.Config.ARGB_8888);

        Log.v("Bitmap width - Height :", width + " : " + height);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }
}
