package com.example.computer.yogaapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class Search extends AppCompatActivity implements View.OnClickListener {
    Button search_button;


    @Override
    public void onClick(View v) {
        //when you click the browse button dump the generalPoses and generalSequences onto the page
        //later need to sort by just poses or just sequences
        switch(v.getId())
        {


            case R.id.search_button:
                startActivity(new Intent(this, Login.class));
                break;

        }


    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        try{
            SQLiteDatabase yogaDB = this.openOrCreateDatabase("Users", MODE_PRIVATE, null);
            yogaDB.execSQL("CREATE TABLE IF NOT EXISTS generalPoses (englishName VARCHAR, sanskritName VARCHAR, picture BLOB, description VARCHAR)"); //initializing a picture?
            //do we need to specify the size of the VARCHAR?
            yogaDB.execSQL("INSERT INTO generaPoses (englishName, sanskritName, picture, description) VALUES 'downward-dog','adho mukha shvanasana', downward_dog.jpg, 'This is a downward dog.' ");
            //Next step is getting the name, username and password from the textedit
            Cursor c2 = yogaDB.rawQuery("SELECT * FROM generalPoses", null);
            int englishNameIndex = c2.getColumnIndex("englishName");
            int sanskritNameIndex = c2.getColumnIndex("sanskritName");
            int pictureIndex = c2.getColumnIndex("picture");
            int descriptionIndex = c2.getColumnIndex("description");
            c2.moveToFirst(); //starts with first entry in database
            while(c2 != null)
            {
                Log.i("englishName", c2.getString(englishNameIndex)); //puts the name in a log
                Log.i("sanskritName", c2.getString(sanskritNameIndex));
                Log.i("picture", c2.getString(pictureIndex));
                Log.i("description", c2.getString(descriptionIndex));

                c2.moveToNext();
            }



            yogaDB.execSQL("CREATE TABLE IF NOT EXISTS generalSequences (name VARCHAR, username VARCHAR, password VARCHAR)"); //initializing a long description
            yogaDB.execSQL("CREATE TABLE IF NOT EXISTS privatePoses (name VARCHAR, username VARCHAR, password VARCHAR)");
            yogaDB.execSQL("CREATE TABLE IF NOT EXISTS privateSequences (name VARCHAR, username VARCHAR, password VARCHAR)");




        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

    }

}
