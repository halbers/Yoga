package com.example.computer.yogaapp;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

/**
 * Created by Vlad Schnakovszki, using functionality developed by Martynas Buivys
 */
public class ImageHelper {

    public static double getScaleFactor(int iMasterSize, int iTargetSize) {
        // There was a mistake regarding the if statement here as you can see.
        // If you're here trying to solve a bug, have a look at MiscHelpers' history on GitHub.
        //if (iMasterSize > iTargetSize) {
        //    return (double) iTargetSize / (double) iMasterSize;
        //} else {
        return (double) iTargetSize / (double) iMasterSize;
        //}
    }

    /**
     * Stores the specified bitmap to file.
     * Based on: http://stackoverflow.com/a/673014
     *
     * @param bitmap - The bitmap to store.
     * @param file   - The file where to store it.
     * @return true if write succeeded, false otherwise.
     */
    public static boolean writeBitmapToFile(Bitmap bitmap, File file) {
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            // PNG is a lossless format, the compression factor (100) is ignored
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return false;
    }

    /**
     * Will rotate the specified image file to the right orientation.
     *
     * @param imageFile - The image file to rotate.
     */
    // Based on: http://stackoverflow.com/a/14066265
    public static void fixImageFileOrientation(File imageFile) {
        Bitmap fixedBitmap = null;

        try {
            String imagePath = imageFile.getAbsolutePath();
            ExifInterface ei = new ExifInterface(imagePath);
            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    fixedBitmap = rotateBitmap(BitmapFactory.decodeFile(imagePath), 90);
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    fixedBitmap = rotateBitmap(BitmapFactory.decodeFile(imagePath), 180);
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    fixedBitmap = rotateBitmap(BitmapFactory.decodeFile(imagePath), 270);
                    break;
            }

            if (fixedBitmap != null) {
                writeBitmapToFile(fixedBitmap, imageFile);
            }
        } catch (Exception ex) {
            //
        } finally {
            if (fixedBitmap != null) {
                fixedBitmap.recycle();
            }
        }
    }

    public static File createCacheRandomImageFile(Context context) throws IOException {
        Random random = new Random();
        String fileName = "image_random_" + random.nextInt(1000000000);
        return createCacheImageFile(context, fileName);
    }

    public static File createCacheImageFile(Context context, String imageFileName) throws IOException {
        return File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                context.getExternalCacheDir()      /* directory */
        );
    }

    /**
     * Pulls out an image from assets folder
     *
     * @param context - current context
     * @param path    - relative path to file, i.e. "animals/aardvark.jpg"
     * @return a Bitmap
     */
    public static Bitmap getBitmapFromAsset(Context context, String path) {
        AssetManager assetManager = context.getAssets();
        InputStream inputStream = null;
        try {
            inputStream = assetManager.open(path);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return BitmapFactory.decodeStream(inputStream);
    }

    public static Bitmap decodeImageFile(File imageFile) {
        return BitmapFactory.decodeFile(imageFile.getAbsolutePath());
    }

    public static int getExifImageFileOrientation(File imageFile) throws NullPointerException, IOException {
        String imagePath = imageFile.getAbsolutePath();
        ExifInterface ei = new ExifInterface(imagePath);
        return ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
    }

    /**
     * Rotates the given bitmap by the angle specified as an EXIF orientation.
     *
     * @param sourceBitmap    - The bitmap to rotate.
     * @param exifOrientation - The EXIF orientation of the file (use the getExifImageFileOrientation() method).
     * @return the rotated bitmap.
     */
    public static Bitmap rotateBitmap(Bitmap sourceBitmap, int exifOrientation) {
        Matrix matrix = new Matrix();
        switch (exifOrientation) {
            case ExifInterface.ORIENTATION_ROTATE_90:
                matrix.postRotate(90);
                break;
            case ExifInterface.ORIENTATION_ROTATE_180:
                matrix.postRotate(180);
                break;
            case ExifInterface.ORIENTATION_ROTATE_270:
                matrix.postRotate(270);
                break;
            default:

        }

        return Bitmap.createBitmap(sourceBitmap, 0, 0, sourceBitmap.getWidth(), sourceBitmap.getHeight(), matrix, true);
    }

    /**
     * Scales the Bitmap to the size specified in the parameters.
     *
     * @param context - Your correct context.
     * @param bitmap  - The bitmap file to be rotated.
     * @return the scaled bitmap
     */
    public static Bitmap scaleBitmap(Context context, Bitmap bitmap) {
        double heightFactor = ImageHelper.getScaleFactor(bitmap.getHeight(), context.getResources().getInteger(R.integer.image_height));
        double widthFactor = ImageHelper.getScaleFactor(bitmap.getWidth(), context.getResources().getInteger(R.integer.image_width));
        double scale = Math.min(heightFactor, widthFactor);
        int desiredHeight = (int) (bitmap.getHeight() * scale);
        int desiredWidth = (int) (bitmap.getWidth() * scale);

        // If image needs to be scaled then do that, otherwise return the unscaled image.
        if (bitmap.getWidth() > desiredWidth || bitmap.getHeight() > desiredHeight) {
            bitmap = Bitmap.createScaledBitmap(bitmap, desiredWidth, desiredHeight, true);
        }

        return bitmap;
    }

    /**
     * Processes an image file from the camera. It will decode it, rotate it to the right position and scale it.
     * Optionally, it can either save the image back into the file or delete the file from the disk.
     * !!! Make sure you ALWAYS get the result of this and recycle it OR set discardBitmap to true to avoid Out of Memory errors !!!
     *
     * @param context                  - Your current context.
     * @param imageFile                - The file containing the image.
     * @param saveProcessedImageToFile - Flag specifying whether to save the processed image to the file.
     * @param deleteImageFile          - Flag specifying whether to delete the image file.
     * @param discardBitmap            - Flag specifying whether to recycle the Bitmap. Null will be returned if true.
     * @return a Bitmap representing the processed image
     */
    public static Bitmap processCameraImageFile(Context context, File imageFile, boolean saveProcessedImageToFile, boolean deleteImageFile, boolean discardBitmap) {
        if (imageFile == null) return null;

        if (saveProcessedImageToFile && deleteImageFile) {
            throw new AssertionError("Requesting an image save as well as a deletion does not make sense.");
        }

        // Extract the image to a Bitmap.
        Bitmap imageBitmap = decodeImageFile(imageFile);

        // Attempt to rotate the image to the correct position.
        try {
            int exifOrientation = getExifImageFileOrientation(imageFile);
            imageBitmap = rotateBitmap(imageBitmap, exifOrientation);
        } catch (Exception ex) {
            //
        }

        // Attempt to scale the image.
        try {
            imageBitmap = ImageHelper.scaleBitmap(context, imageBitmap);
        } catch (Exception ex) {
            //
        }

        if (saveProcessedImageToFile) {
            writeBitmapToFile(imageBitmap, imageFile);
        }

        if (deleteImageFile) {
            imageFile.delete();
        }

        if (discardBitmap) {
            imageBitmap.recycle();
            imageBitmap = null;
        }

        return imageBitmap;
    }
}
