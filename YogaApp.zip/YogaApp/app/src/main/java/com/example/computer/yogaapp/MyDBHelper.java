package com.example.computer.yogaapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDBHelper extends SQLiteOpenHelper{
    private static  final String DBNAME = "poses.db";
    private static  final int VERSION = 1;

    private static  final String TABLE_NAME = "employees";
    public static  final String ID = "Id";
    public static  final String ENGLISH_NAME = "englishName";
    public static  final String SANSKRIT_NAME = "sanskritName";
    public static  final String DESCRIPTION = "description";
    public static  final String PICTURE = "picture";



    private SQLiteDatabase myDB;

    public MyDBHelper(Context context) {
        super(context, DBNAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//create table
        String queryTable ="CREATE TABLE " + TABLE_NAME + " (" +
            ID + " INTEGER PRIMARY KEY, " +
                ENGLISH_NAME + " TEXT NOT NULL, " +
                SANSKRIT_NAME + " TEXT NOT NULL, " +
                DESCRIPTION + " TEXT NOT NULL, " +
                PICTURE + " BLOB " +
            ")";
        db.execSQL(queryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void openDB(){
        myDB = getWritableDatabase();
    }
    public void closeDB(){
        if(myDB != null && myDB.isOpen()){
            myDB.close();
        }
    }
    public long insert(String englishName, String sanskritName, String description, byte[] picture ){
        ContentValues values = new ContentValues();
        if(picture != null) {
            values.put(ENGLISH_NAME, englishName);
            values.put(SANSKRIT_NAME, sanskritName);
            values.put(DESCRIPTION, description);
            values.put(PICTURE, picture);

            return myDB.insert(TABLE_NAME, null, values);
        }else{
            return myDB.insert(TABLE_NAME, null, values);
        }

    }
    public long insertPreload(String englishName, String sanskritName, String description, byte[] picture ){
        ContentValues values = new ContentValues();
        values.put(ENGLISH_NAME, englishName);
        values.put(SANSKRIT_NAME, sanskritName);
        values.put(DESCRIPTION, description);
        values.put(PICTURE, picture);

        return myDB.insert(TABLE_NAME, null, values);

    }

    public long update(int id, String englishName, String sanskritName, String description, byte[] picture ){
      ContentValues values = new ContentValues();
        values.put(ENGLISH_NAME, englishName);
        values.put(SANSKRIT_NAME, sanskritName);
        values.put(DESCRIPTION, description);
        values.put(PICTURE, picture);

        String where = ID + " = " + id;
        return myDB.update(TABLE_NAME, values, where, null);

    }
    public long delete(int id){

        String where = ID + " = " + id;
        return myDB.delete(TABLE_NAME, where, null);

    }
    //retrieving the data
    public Cursor getAllRecords(){
      String query = "SELECT * FROM " + TABLE_NAME;
      return myDB.rawQuery(query, null);
    }
}
