package com.example.computer.yogaapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Register extends AppCompatActivity implements View.OnClickListener {
    Button registerButton;
    EditText editTextName, editTextUserName, editTextPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editTextName = (EditText)findViewById(R.id.editTextName);
        editTextUserName = (EditText)findViewById(R.id.editTextUserName);
        editTextPass = (EditText)findViewById(R.id.editTextPass);
        registerButton = (Button) findViewById(R.id.registerButton);

        registerButton.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch(v.getId())
        {
            case R.id.registerButton:

                String username = editTextUserName.getText().toString();
                String password = editTextPass.getText().toString();

                User registeredData = new User(username, password);

                break;
        }
    }
}
