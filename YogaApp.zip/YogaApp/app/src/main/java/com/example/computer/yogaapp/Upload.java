package com.example.computer.yogaapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Upload extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
         try {
             SQLiteDatabase yogaDB = this.openOrCreateDatabase("yogaDB", MODE_PRIVATE, null);
             yogaDB.execSQL("CREATE TABLE IF NOT EXIST pulicPoses (name VARCHAR, sanskrit VARCHAR)");
             yogaDB.execSQL("INSERT INTO publicPoses (name, sanskrit) VALUES ('downward dog', 'adho mukha shvanasana')");

             Cursor c = yogaDB.rawQuery("SELECT * FROM publicPoses", null);
             //made to loop through the table publicPoses
             //next there need to be indexes
             int nameIndex = c.getColumnIndex("name");
             int sanskritIndex = c.getColumnIndex("sankskrit");

             c.moveToFirst();
             while (c != null){
                 Log.i("name", c.getString(nameIndex));
                 Log.i("sanskrit", c.getString(sanskritIndex));

                 c.moveToNext();


             }
         }
         catch(Exception e){
             e.printStackTrace();
         }

        ListView PosesListView = (ListView)findViewById(R.id.PosesListView);
        ArrayList<String> poses = new ArrayList<String>();
        //new database called poses


        poses.add("downwardDog");
        poses.add("cobra");
        poses.add("crow");
        poses.add("lotus");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, poses);
        //will need to be DBADapter


        PosesListView.setAdapter(arrayAdapter);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

}
